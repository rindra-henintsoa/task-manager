-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 29 nov. 2024 à 07:14
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `task-manager`
--

-- --------------------------------------------------------

--
-- Structure de la table `doctrine_migration_versions`
--

CREATE TABLE `doctrine_migration_versions` (
  `version` varchar(191) NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20241128071112', '2024-11-28 08:11:38', 27),
('DoctrineMigrations\\Version20241128102616', '2024-11-28 11:26:50', 45),
('DoctrineMigrations\\Version20241128112010', '2024-11-28 12:20:17', 10);

-- --------------------------------------------------------

--
-- Structure de la table `messenger_messages`
--

CREATE TABLE `messenger_messages` (
  `id` bigint(20) NOT NULL,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `available_at` datetime NOT NULL COMMENT '(DC2Type:datetime_immutable)',
  `delivered_at` datetime DEFAULT NULL COMMENT '(DC2Type:datetime_immutable)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `tache`
--

CREATE TABLE `tache` (
  `id` int(11) NOT NULL,
  `utilisateur_assigne_id` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `descritpion` longtext NOT NULL,
  `status` varchar(255) NOT NULL,
  `priorite` varchar(255) NOT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  `commentaire` longtext DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `tache`
--

INSERT INTO `tache` (`id`, `utilisateur_assigne_id`, `title`, `descritpion`, `status`, `priorite`, `date_debut`, `date_fin`, `commentaire`) VALUES
(1, 2, 'Tache 1', '<div>desciption 1</div>', 'en attente', 'Basse', '2024-11-18 14:27:00', '2024-11-20 14:27:00', 'test commentaire'),
(2, 7, 'Tache 2', '<div>desciption tâche 2</div>', 'en attente', 'Basse', '2024-11-25 14:28:00', '2024-11-27 14:28:00', 'test commentaire'),
(3, 6, 'Tache 3', '<div>description tâche 3</div>', 'en attente', 'Basse', '2024-12-04 14:28:00', '2024-12-12 14:28:00', 'test commentaire');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(180) NOT NULL,
  `roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`roles`)),
  `password` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `email`, `roles`, `password`, `firstname`, `lastname`) VALUES
(1, 'adminmanager@gmail.com', '[\"ROLE_ADMIN\"]', '$2y$13$RwZdv9G.YB0g2XWs2a3.j.3/gCkVx4mx9zRLcPIP6RxBu0Unnr7su', 'Admin', 'task-manager'),
(2, 'user1@gmail.com', '[\"ROLE_USER\"]', '$2y$13$he7QZrbe5mya0v.2zGqXUetCAIvKQRlWAnHVJ7EsurRZa4j7aZq8i', 'User1', 'user1 lastname'),
(3, 'user5@gmail.com', '[]', 'user5', 'user5', 'user'),
(4, 'user6@gmail.com', '[\"ROLE_ADMIN\"]', 'user6', 'user6', 'user'),
(5, 'user7@gmail.com', '[]', 'user7', 'user7', 'user'),
(6, 'user8@gmail.com', '[\"ROLE_ADMIN\"]', 'user8', 'user8', 'user'),
(7, 'user9@gmail.com', '[\"ROLE_ADMIN\"]', 'user9', 'user9', 'user'),
(8, 'user10@gmail.com', '[\"ROLE_USER\"]', '$2y$13$ZiEMecHSIIYtiJqSHK/UAOmQPjkm8Yg/EmeApKI0smM7c7TBkmOcC', 'user10', 'user');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `doctrine_migration_versions`
--
ALTER TABLE `doctrine_migration_versions`
  ADD PRIMARY KEY (`version`);

--
-- Index pour la table `messenger_messages`
--
ALTER TABLE `messenger_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_75EA56E0FB7336F0` (`queue_name`),
  ADD KEY `IDX_75EA56E0E3BD61CE` (`available_at`),
  ADD KEY `IDX_75EA56E016BA31DB` (`delivered_at`);

--
-- Index pour la table `tache`
--
ALTER TABLE `tache`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_93872075BCC348A6` (`utilisateur_assigne_id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_IDENTIFIER_EMAIL` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `messenger_messages`
--
ALTER TABLE `messenger_messages`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `tache`
--
ALTER TABLE `tache`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `tache`
--
ALTER TABLE `tache`
  ADD CONSTRAINT `FK_93872075BCC348A6` FOREIGN KEY (`utilisateur_assigne_id`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
